/*Renders a page with the given template and data*/
module.exports = (objectRepository, viewName) => {
    return (req, res, next) => {
        return next();
    };
}