/*Deletes a chore from the database
* If successful redirects to /chores/
*/
module.exports = (objectRepository) => {
    return (req, res, next) => {
        return next();
    };
}