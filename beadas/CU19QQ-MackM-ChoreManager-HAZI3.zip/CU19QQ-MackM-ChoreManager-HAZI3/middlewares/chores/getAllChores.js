/*Fetches all chores from the database
* The result is saved to res.locals.allChores
* If there are no family members, res.locals.allChores will be an empty array
*/
module.exports = (objectRepository) => {
    return (req, res, next) => {
        return next();
    };
}